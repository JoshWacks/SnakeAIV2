import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;




public class MyAgent extends za.ac.wits.snake.MyAgent {
	
	private static int[]obstaclesArr=new int[30];

	
	private static ArrayList<Integer>snakeTails=new ArrayList<>();

	

    public static void main(String args[]) throws IOException {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);

            while (true) {
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }


                String[] XY=line.split(" ");
                int appleX=Integer.parseInt(XY[0]);
                int appleY=Integer.parseInt(XY[1]);
                

                int index=0;
                String[] obsXY;
                String[] obs;
                
                
	                for (int obstacle = 0; obstacle < 3; obstacle++) {
	                    obs = br.readLine().split(" ");
	                    for(String s:obs) {
	                    	
	                    	obsXY=s.split(",");
	                    	obstaclesArr[index]=Integer.parseInt(obsXY[0]);
	                    	obstaclesArr[index+1]=Integer.parseInt(obsXY[1]);
	                    	index=index+2;
	                    }
	                }
	  

                


                int mySnakeNum = Integer.parseInt(br.readLine());

                String[] snakeInfo;
                
                String[] headXY;
                int headX = 0;
                int headY = 0;
                
                String[] secondXY;//The second point on the snake, can be the tail or not
                int secondX = 0;
                int secondY = 0;
                
                int mySnakeX=0;
                int mySnakeY=0;
                
                int mySnakeSecondX=0;
                int mySnakeSecondY=0;
                
                
                int move = 0;
                int dir=0;
                snakeTails.clear();
                
                
                
                for (int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();
                    snakeInfo=snakeLine.split(" ");

                    if(snakeInfo[0].equals("alive")) {//only want alive info or it will crash as no head

		                
		                
		               for(int j=3;j<snakeInfo.length-1;j++) {
		            	   headXY=snakeInfo[j].split(",");
			               headX=Integer.parseInt(headXY[0]);
			               headY=Integer.parseInt(headXY[1]);
			                    
			               secondXY=snakeInfo[j+1].split(",");
			               secondX=Integer.parseInt(secondXY[0]);
			               secondY=Integer.parseInt(secondXY[1]);
			               
			               addToTail(headX,headY,secondX,secondY);
		               }
		               
		                
                    }

                    
                    if (i == mySnakeNum ) {
                    	
                    	mySnakeX=Integer.parseInt(snakeInfo[3].split(",")[0]);
                    	mySnakeY=Integer.parseInt(snakeInfo[3].split(",")[1]);
                    	
                    	mySnakeSecondX=Integer.parseInt(snakeInfo[4].split(",")[0]);
                    	mySnakeSecondY=Integer.parseInt(snakeInfo[4].split(",")[1]);
	
                    	
                    }

                }


                dir=getSnakeDirection(mySnakeX,mySnakeY,mySnakeSecondX,mySnakeSecondY);
            	move=appleDirection(appleX,appleY,mySnakeX,mySnakeY,dir);
            	
                if(!checkCollison(mySnakeX,mySnakeY,move)) {
                	move=findValidMove(mySnakeX,mySnakeY,dir);
                }
                
                System.out.println(move);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private static int getSnakeDirection(int hx,int hy,int sx,int sy) {
    	if(hx==sx) {
    		if(hy<sy) {
    			return 0;
    		}
    		else {
    			return 1;
    		}
    	}else {
    		
    		if(hx<sx) {
    			return 2;
    		}
    		else {
    			return 3;
    		}

    	}
    }
    
	
    private static int appleDirection(int appleX,int appleY,int headX,int headY,int dir) { 
		  //Same as game for this methods directions
		  // 0=Up 
		  // 1=Down
		  // 2=Left
		  // 3=Right
	  
		  int difX=headX-appleX; 
		  int difY=headY-appleY;
		  

		  
		  switch(dir) {
		   case 0://Going up
			   
			   if(difY>0) {
				   return 0;//Going Up and must continue up
			   }
			   
			   else {//Needs to turn left or right or turn around
				   	  if(difX<0) {
						  return 3;//Turn right relative to the board
					  }
					  else {
						  return 2;//Turn left relative to the board
					  }
			   }
			   


			   
		   case 1://Going down
			   
			   if(difY<0) {
				   return 1;//Going Down and must continue down
			   }
			   
			   else {//Needs to turn left or right or turn around
					  if(difX<0) {
						  return 3;//Turn right relative to the board
					  }
				   
					  else {
						  return 2;//Turn left relative to the board
					  }
			   }

			   
		case 2://Going Left
			if(difX>0) {
				return 2;
			}
			   
			else {//Needs to turn left or right or turn around
				  if(difY>0) {
					  return 0;//Go up relative to the board
				  }
				  else {
					  return 1;//Go down relative to the board
				  }
			}
			  
			  
		case 3://Going Right
			
			if(difX<0) {
				return 3;
			}
			   
			else {//Needs to turn left or right or turn around
				  if(difY>0) {
					  return 0;//Go up relative to the board
				  }
				  else {
					  return 1;//Go down relative to the board
				  }
			 }
			  

		  }
		  return 5;
		  


	 }
	  
	  
	 private static boolean checkCollison(int headX,int headY,int nextMove) {

		 switch(nextMove) {
		 	case 0:
		 		
		 		if(headY-1<0) {
		 			return false;
		 		}
		 		for(int i=0;i<30;i=i+2) {
		 			if((obstaclesArr[i]==headX && obstaclesArr[i+1]==headY-1) ) {
		 				return false;
		 			}
		 		}
		 		for(int i=0;i<snakeTails.size()-1;i++) {
		 			if(snakeTails.get(i)==headX && snakeTails.get(i+1)==headY-1) {
		 				return false;
		 			}
		 		}
		 		
		 	break;
		 	
		 	case 1:
		 		if(headY+1>50) {
		 			return false;
		 		}
		 		for(int i=0;i<30;i=i+2) {
		 			if(obstaclesArr[i]==headX && obstaclesArr[i+1]==headY+1) {
		 				return false;
		 			}
		 		}
		 		for(int i=0;i<snakeTails.size()-1;i++) {
		 			if(snakeTails.get(i)==headX && snakeTails.get(i+1)==headY+1) {
		 				return false;
		 			}
		 		}
		 		
		 	break;
		 	
		 	case 2:
		 		if(headX-1<0) {
		 			return false;
		 		}
		 		for(int i=0;i<30;i=i+2) {
		 			if(obstaclesArr[i]==headX-1 && obstaclesArr[i+1]==headY) {
		 				return false;
		 			}
		 		}
		 		for(int i=0;i<snakeTails.size()-1;i++) {
		 			if(snakeTails.get(i)==headX-1 && snakeTails.get(i+1)==headY) {
		 				return false;
		 			}
		 		}
		 		
		 	break;
		 	
		 	case 3:
		 		if(headX+1>50) {
		 			return false;
		 		}
		 		for(int i=0;i<30;i=i+2) {
		 			if(obstaclesArr[i]==headX+1 && obstaclesArr[i+1]==headY ) {

		 				return false;
		 			}
		 		}
		 		
		 		for(int i=0;i<snakeTails.size()-1;i++) {
		 			if(snakeTails.get(i)==headX+1 && snakeTails.get(i+1)==headY) {
		 				return false;
		 			}
		 		}
		 		
		 	break;
		 		
		 		
		 }
		 
		 return true;
	 }
	 
	 private static int findValidMove(int headX,int headY,int dir) {
		 
		 for(int i=0;i<4;i++) {
			 if(checkCollison(headX,headY,i)) {
				 return i;
			 }
		 }
		 
//		 switch(dir) {
//		 	case 0:
//		 		for(int i=2;i<4;i++) {
//		 			
//			 		if(checkCollison(headX,headY,i) && i!=1) {
//			 			return i;
//			 		}
//		 		}
//		 		break;
//		 		
//		 	case 1:
//		 		for(int i=2;i<4;i++) {
//		 			
//			 		if(checkCollison(headX,headY,i)) {
//			 			return i;
//			 		}
//		 		}
//		 		break;
//		 		
//		 	case 2:
//		 		for(int i=0;i<2;i++) {
//		 			
//			 		if(checkCollison(headX,headY,i)) {
//			 			return i;
//			 		}
//		 		}
//		 		break;
//		 		
//		 	case 3:
//		 		for(int i=0;i<2;i++) {
//		 			
//			 		if(checkCollison(headX,headY,i) ) {
//			 			return i;
//			 		}
//		 		}
//		 		break;
//		 		
//		 }
		 System.out.println("log "+ "Can't find a move");
		 return 2;
		 
	 }
	 
	 private static void addToTail(int firstX,int firstY,int secondX,int secondY) {
		 if(firstX==secondX) {
			 
			 if(secondY>firstY) {
				 for(int i=firstY;i<=secondY;i++) {
					 snakeTails.add(firstX);
					 snakeTails.add(i);
				 }
			 }
			 else {
				 for(int i=secondY;i<=firstY;i++) {
					 snakeTails.add(firstX);
					 snakeTails.add(i);
				 }
			 }
			 
		 }
		 else {
			 
			 if(secondX>firstX) {
				 for(int i=firstX;i<=secondX;i++) {
					 snakeTails.add(i);
					 snakeTails.add(firstY);
				 }
			 }
			 else {
				 for(int i=secondX;i<=firstX;i++) {
					 snakeTails.add(i);
					 snakeTails.add(firstY);
				 }
			 }
		 }
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	  
	  
}